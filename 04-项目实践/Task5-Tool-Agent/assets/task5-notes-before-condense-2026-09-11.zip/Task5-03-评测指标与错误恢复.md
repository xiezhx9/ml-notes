---
tags: [LLM, Agent, Evaluation, Error-Recovery, ReAct]
aliases: [Agent 错误恢复, Tool Agent 评测, Task5验收方法]
updated: 2026-09-10
---

# Task 5.3：验收步骤、评测指标与错误恢复

> [!summary] 核心结论
> 验收需要明确“评谁、依据什么、分母是谁”。M4 的答案命中率、S1–S3 的联合成功率、S4 的恢复率不能互换。测试程序应独立判分，报告要保留逐题证据和版本信息。

返回总览：[[Task5-Tool-Agent学习索引]]  
实现依据：`eval/run.py`、`src/experiments.py`，源码 hash 见 [本次快照](assets/task5-experiment-snapshot-2026-09-10.json)。

## 1. M1–M4 的验收地图

| 要求 | 检查对象 | 当前验收方式 | 能证明什么 |
|---|---|---|---|
| M1 | 四个工具 | tools_individual 各调用一组输入 | 给定输入下基本接口可用 |
| M2 | ReAct 循环 | 代码检查 + 确定性消息测试 + 真实 Trace | 路由、回灌、终止机制能连起来 |
| M3 | 错误回灌 | 工具/解析异常进入 Observation，下一轮继续 | 单次工具异常不直接摧毁整个循环 |
| M4 | 十题答案 | multi_tool_success_rate > 0.60 | 最终答案满足当前关键词规则 |
| S4 | 一次注入后的恢复 | recover_rate > 0.40 | 当前注入与补救定义下的恢复比例 |

M2/M3 当前没有各自独立、覆盖全面的自动测试入口；不能把跑过 M4 当作所有异常分支都已验证。

### M1 到底测试了哪些输入

| 工具 | 冒烟输入 | 断言 |
|---|---|---|
| calculator | `2 + 3 * 4` | 返回含 `14` |
| python_sandbox | `print(sum(range(10)))` | 返回含 `45` |
| file_search | 在项目根搜 `README.md` | 返回含 `README.md` |
| wiki | 查询 `Alan Turing` | 返回字符串长度 > 50 |

wiki 抛异常可被标记为网络跳过，不进入该组必过门槛；其余工具有一个失败，M1 即失败。wiki “长度够长”不证明条目正确，M1 也不检查所有参数边界、资源限制和安全性。

## 2. 推荐的实际验收顺序

### 第一步：冻结配置与输入

在本地项目目录执行：

```bash
cd /Users/xue/Desktop/llm-beginner/task-5-tool-agent
uv sync --locked --extra qwen-agent
```

记录代码版本、`uv.lock`、任务 JSON、fixture、prompt、模型 ID、endpoint、温度、步数和请求超时。不要把 .env 内容或 API key 写入报告。

已有数据时不必重新生成。`data/download.py` 会重写 tasks 和两个夹具；仅在需要重新准备默认数据、且已经保留自定义内容时运行。脚本打印的本地模型部署提示是早期模板，实际实验使用远程 API。

### 第二步：离线检查工具与协议

先测试三个本地工具，再检查解析器：

- 合法 JSON、JSON 围栏、数组参数、缺标签；
- 非空/空 Final Answer；
- 未知工具；
- 工具抛异常；
- Observation 是否回到下一轮 messages；
- 达到 max_steps 后能否有限退出并保留状态。

下面是无需模型 API 的回灌测试示例；通过只代表循环逻辑，不代表模型能力：

```bash
uv run python - <<'PY'
from src.agent import ReActAgent

outputs = iter([
    'Thought: 计算。\nAction: calculator\nAction Input: {"expression":"6 * 7"}',
    'Thought: 已得到结果。\nFinal Answer: 42',
])
seen = []
agent = ReActAgent()

def fake_model(messages):
    seen.append([dict(message) for message in messages])
    return next(outputs)

agent.call_model = fake_model
trace = agent.run("计算 6 * 7")
assert seen[1][-1]["content"] == "Observation: 42"
assert trace["steps"][0]["action"] == "calculator"
assert trace["final_answer"] == "42"
print("回灌与终止逻辑通过；这不是模型实验成绩。")
PY
```

### 第三步：执行真实自检

```bash
uv run python eval/run.py
```

检查生成的 `eval/result.json` 每一项的 `pass/rate/details`。当前共用运行壳会捕获异常并写报告，**进程退出码为 0 不一定表示全部测试通过**；不要只看“命令执行完了”。

十题 M4 必须至少 7 题命中，因为要求是严格 `> 0.60`；6/10 不通过。十题恢复验收至少 5 题，因为严格 `> 0.40`。

### 第四步：分开运行 S1–S4

```bash
uv run --extra qwen-agent python run_experiments.py s1 --repetitions 3
uv run python run_experiments.py s2 --repetitions 3
uv run python run_experiments.py s3 --repetitions 3
uv run python run_experiments.py s4 --repetitions 3
```

S2 另需 S2_BASE_URL、三个 S2_MODEL_* 和 S2_API_KEY。这些命令会真实调用远程服务，并覆盖各实验的固定输出文件；重跑前应另存旧报告。

S1–S3 没有统一硬编码的“加分实验及格线”，目标是有效对照与可信解释。不能把 M4 的 >60% 自动套成每个变体的门槛。

### 第五步：审阅报告和失败轨迹

顺序建议：`config/design → sample_count → summary/metrics → comparisons → runs[].details`。

每个失败样本回答：

1. 题目与标准是否一致？
2. 模型究竟输出了什么动作和参数？
3. 工具是否真的成功，结果是否相关？
4. 下一步是否用到了 Observation？
5. 最终答案遗漏了什么？
6. 是任务失败、协议失败、工具故障还是评分器误判？

## 3. 答案命中率的实际算法

设 $A_i$ 是第 $i$ 次运行的最终答案是否符合标准：

$$
\mathrm{AnswerRate}=\frac{\sum_{i=1}^{N} A_i}{N}.
$$

`answer_matches` 先小写化，删除中英文逗号和空白，再执行：

- 顶层列表：所有项都要满足，逻辑 AND。
- 子列表：其中任一字符串出现即可，逻辑 OR。
- 比较方式是子串匹配，不是语义判断或数值等价。

例：

```json
["1947", ["78", "79"]]
```

要求最终答案同时含 `1947` 与 `78/79` 之一。出生年份出现在工具 Observation、但没写进 final_answer，依然判失败。

> [!example] 真实 S2 案例
> 14B 三轮都调用了 wiki → calculator，工具给出 1947 和 79，最终只回答“2026 年将满 79 岁”。报告把它标成 answer_mismatch，原因是漏了题目要求的出生年份，不是减法算错。

### 这种评分器的优点与盲点

优点：便宜、确定、方便复算。盲点包括：

- “位数为 6”曾不匹配旧版“6位”，构成表达层假阴性。
- 期望 `2` 也可能匹配 `12`；包含正确关键词的否定句也可能误过。
- Task8 接受 `45.01111`，所以并没有严格验收“恰好六位小数”的显示格式。
- 回文题仅检查若干字符串，未验证 True/False 是否分别对应正确单词。
- 不验证引用是否支持答案，也不检查夹带的错误陈述。

后续可用结构化结果、数值容差、字段映射、证据核对和人工校准的 grader；不能只靠不断增加关键词修补所有问题。

## 4. 工具覆盖、精确选择与联合成功

设 $E_i$ 是期望工具集合，$U_i$ 是 Trace 中记录过的动作名称集合：

$$
C_i=\mathbf{1}[E_i\subseteq U_i],\qquad
X_i=\mathbf{1}[E_i=U_i],\qquad
J_i=A_i\land C_i.
$$

分别汇总得到 expected_tool_coverage_rate、exact_tool_selection_rate 和 joint_success_rate。

| 期望 wiki + calculator；假定答案正确 | 覆盖 C | 精确 X | 联合 J |
|---|---:|---:|---:|
| 两者各调用一次 | 1 | 1 | 1 |
| calculator 额外重试一次 | 1 | 1 | 1 |
| 两者之外还调用 sandbox | 1 | 0 | 1 |
| 只调用 wiki | 0 | 0 | 0 |
| 不调用任何工具直接回答 | 0 | 0 | 0 |

直接回答指标为：

$$
D_i=\mathbf{1}[E_i\ne\varnothing \land U_i=\varnothing].
$$

它在当前实验被判联合失败，但 A 仍可能为 1。对于普通问候等不需要工具的任务，“不调用工具”反而可能是正确行为；Task5 的规则服务于它的特定测试集。

### 特别容易误解的实现细节

- `used_tools` 保留重复动作，计算调用次数时会重复计数；计算集合指标时去重。
- 提取器看的是 step 中的动作名，不要求该调用有成功返回。因此覆盖成功不等于所有工具执行成功。
- 集合指标不检查顺序、参数和依赖关系。
- `extra_tool_used` 可以出现在 failure_types 中，但不一定导致 `success=False`：联合成功允许额外工具。
- S1–S3 的 `details[].success` 指联合成功；M4 的同名字段指答案正确；S4 则指恢复成功。
- M4 的 `used_expected_tools` 只是诊断字段，旧实现还用了名称子串判断；正式实验使用名称集合关系。

## 5. 步骤数、时延与 Token

| 字段 | 当前口径 |
|---|---|
| step_count / average_steps | len(steps)，手写版不包含最终回答轮，可能包含解析错误 |
| total_tool_calls / average_tool_calls | 非空动作名条数，重试重复计数；不等于成功执行数 |
| duration_seconds | 墙钟耗时，包含网络、模型、工具和恢复开销 |
| S1/S2 average_duration_seconds | 该变体总耗时 / 全部样本数 |
| system_prompt_chars | 字符数，既不是 token 数，也不含所有序列化开销 |

异常样本仍留在总样本分母，但若 run 抛异常没返回部分 Trace，该样本已消耗的步骤可能未计入 total_steps。因而步骤均值还可能低估失败成本。

当前没有完整 token usage、计费和 P95 记录，不能从 prompt 字符数推导出精确费用或吞吐率。

## 6. S4 恢复指标

定义已记录的注入 $I_i$、注入后的补救标志 $R_i$、答案正确 $A_i$：

$$
K_i=I_i\land R_i\land A_i.
$$

$$
\mathrm{InjectionRate}=\frac{\sum I_i}{N},\quad
\mathrm{RecoveryRate}=\frac{\sum K_i}{N},\quad
\mathrm{RecoveryGivenInjection}=\frac{\sum K_i}{\sum I_i}.
$$

当前 `retried` 的精确实现：注入之后，又一次工具调用正常返回且工具名非空，就置 True；换工具也算。它没有验证“该动作确实修复了前一步”，空串或 None 的正常返回也可能计入。

独立 S4 用 `I and R and A`；自检中的 error_recovery 用 `retried and A`，依赖 retried 只能在注入后置位的实现不变量。两者目前接近，但不能把函数名字相似当作完全相同的实验。

S4 恢复成功不额外要求 $C_i=1$。如果研究“错误后仍完成完整工具流程”，应另外定义 `I and R and A and C`，并报告这是新增口径。真实三轮分解见 [[Task5-07-S4错误恢复实验报告]]。

## 7. 聚合与复现的原则

每组 10 题重复 3 轮，$N=30$。聚合应先加计数再相除：

$$
\hat p=\frac{\sum_r \mathrm{success}_r}{\sum_r N_r}.
$$

各轮样本数相同时，它恰好等于每轮成功率均值；不同样本数时一般不等。例：9/10 与 1/2 的总体成功率为 10/12，而不是两个百分比平均后的 70%。

报告保留三位小数，因此 comparison 的差值可能是已舍入比例之差。例如 20/30 − 25/30 精确为 −16.67 个百分点，报告可能显示 `-0.166`。复习以原始计数为准。

`seed=42` 主要固定变体的执行顺序随机化；并未证明远程模型被固定了推理随机种子。temperature=0、固定顺序均不等于服务端逐次完全一致。

十题重复三次可以观察运行波动，却不能当作三十种独立问题。进一步推断应扩大独立任务集，并按任务配对分析或做适当的按任务分组重采样。

## 8. 本次已有验收记录

`eval/result.json` 保存 M1 通过、M4 10/10、error_recovery 10/10；该文件本身没有完整运行时间及输入 hash，且 Task1 仍是较旧的关键词集。因此只称为“保存的历史自检”，不把它包装为本次重新执行的验收。

正式实验使用更丰富的报告结构；S1–S4 的目标和逐题解释在各专题中。未来复现时应保存任务原文、任务/提示词 hash、版本、分层错误和实际计费数据。

## 9. 自测

1. M4 为 6/10，是否通过？S4 为 4/10 呢？
2. 命令 exit code=0，为什么仍要打开 eval/result.json？
3. ["1947", ["78", "79"]] 是什么逻辑？
4. 答案正确且多调用一个工具，联合成功和精确选择分别怎样？
5. 两个要求的工具都出现，但都报错，覆盖率可能仍为 1 吗？
6. 直接回答正确，为什么 M4 可通过、S1–S3 的该样本却失败？
7. 为什么 step_count 不等于 token、费用或真实 API 请求数？
8. 20 次恢复、22 次已记录注入、30 次运行，对应哪两个恢复率？
9. 两轮分别 9/10 与 1/2，总体成功率是多少？
10. 为什么 expected_tools 全出现仍不足以证明使用了 Observation？
11. 重复三遍十道题是不是三十道独立题？
12. 为什么同名 success 字段不能跨报告直接拼表？

### 自测标准答案

> [!success]- 标准答案：1. 都不通过
> 两个阈值均为严格大于：M4 >0.6，S4 >0.4。10 题分别至少 7 题和 5 题。

> [!success]- 标准答案：2. 运行壳可能吞掉测试异常
> 当前共用运行壳把失败写进 JSON，并不保证返回非零进程状态。以每项 pass 和失败细节为准。

> [!success]- 标准答案：3. 顶层 AND、嵌套 OR
> final_answer 必须含 1947，并含 78 或 79 中至少一个；中间 Trace 出现但最终答案没出现也不满足。

> [!success]- 标准答案：4. J=1，X=0
> 前提是要求的工具都覆盖。联合成功允许额外调用，精确选择不允许额外工具名，但允许同工具重复。

> [!success]- 标准答案：5. 可能
> 提取器统计动作名，不验证执行成功。必须增加执行状态和有效证据指标才能排除这种假象。

> [!success]- 标准答案：6. 门槛不同
> M4 只看答案；S1–S3 的 success 要求答案和期望工具覆盖。答案分数本身仍可记为正确。

> [!success]- 标准答案：7. 记录和成本粒度不同
> 最终回答、内部重试、各轮输入输出长度、缓存和工具耗时都没有被一个 step_count 完整表示。

> [!success]- 标准答案：8. 66.67% 与 90.91%
> 全部运行恢复率为 20/30，已记录注入条件下恢复率为 20/22。二者分别回答端到端和条件能力问题。

> [!success]- 标准答案：9. 10/12≈83.33%
> 先合并成功数与样本数，不能对不同分母的百分比做无权平均。

> [!success]- 标准答案：10. 集合不检查因果依赖
> 模型可能乱用参数、跳过结果、按记忆计算，甚至只让工具名称出现。需要检查后一步参数与前一步证据的对应关系。

> [!success]- 标准答案：11. 不是
> 仍只有十种任务，重复运行相关。它有助于观察波动，但不能替代新任务覆盖。

> [!success]- 标准答案：12. 语义不同
> M4 是答案正确，S1–S3 是联合成功，S4 是注入后的恢复。拼表前必须先统一定义与输入版本。
