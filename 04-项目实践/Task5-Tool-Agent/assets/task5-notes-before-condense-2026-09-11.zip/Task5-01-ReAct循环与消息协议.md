---
tags: [LLM, Agent, ReAct, Prompt, Tool-Calling]
aliases: [ReAct 循环, Agent 消息协议]
updated: 2026-09-10
---

# Task 5.1：ReAct 循环与消息协议

> [!summary] 核心结论
> ReAct 将模型的推理与动作选择放到环境反馈闭环中。Task5 已实现基础机制：模型产出动作，执行器调用真实工具，结果回到上下文，模型再决定继续还是完成。更强的规划、记忆、反思并非 ReAct 的必需组件。

返回总览：[[Task5-Tool-Agent学习索引]]  
代码定位：`src/agent.py` 中 `build_system_prompt / parse_action / run`。

## 1. Reason、Act、Observe 分别是谁做的

| 环节 | 本项目的承担者 | 实际产物 |
|---|---|---|
| Reason | LLM 根据任务、历史和工具说明决定下一步 | 教学格式下的 Thought 与动作选择 |
| Act | LLM 提出调用，Python 注册表路由并执行 | 工具名、参数、真实执行结果 |
| Observe | 执行器取得结果或异常并回填 | 下一轮 messages 中的 Observation |
| Finish | 模型提出最终回答，程序结束循环 | final_answer；正确与否再由评测判断 |

原始 ReAct 工作强调推理与行动轨迹交替，并利用环境反馈更新后续行动。[ReAct 原论文](https://arxiv.org/abs/2210.03629)

设历史为 $h_t$、工具动作为 $a_t$、观察为 $o_t$，可用下式理解：

$$
a_t \sim \pi_\theta(\cdot \mid h_t),\qquad
o_t=\operatorname{Execute}(a_t),\qquad
h_{t+1}=h_t\oplus(a_t,o_t).
$$

其中 $\pi_\theta$ 是模型的动作选择行为；程序没有另外手写一个通用推理算法。

## 2. 为什么感觉“只写了一个循环”

代码负责让已有模型能力进入可执行系统，因此大量工作是消息组织、解析、执行和异常处理。推理主要发生在模型内部。

需要纠正一个容易误读的点：

- `parse_thought` 的结果只放进 Trace，没有独立 Python 分支按 Thought 做推理判断。
- 但完整 `model_response` 会作为 assistant 消息重新加入历史，包含文本 Thought。
- 自回归生成时，Action 也可能依赖前面已生成的 Thought。因此“程序没有分析 Thought”不等于“Thought 对模型完全无影响”。
- 同样，打印出长 Thought 也不能证明模型正确利用了工具结果。应通过动作依赖与任务结果验证。

Task5 已有基础 ReAct；尚未深入的主要是长任务规划、证据验证、重复行为检测和系统化行为实验。扩展方向见 [[Task5-08-现代Agent优化与行为复习]]。

## 3. 当前代码的完整控制流

```mermaid
flowchart TD
    B["构建 system prompt 与初始 messages"] --> C["调用模型"]
    C -->|API 异常| A["异常离开 run；外层按题记录失败"]
    C --> F{"解析 Final Answer"}
    F -->|非空答案| DONE["立即返回 AgentTrace"]
    F -->|没有该标签| P["将原始回复加入 messages；解析 Action 与 JSON"]
    F -->|标签存在但答案为空| EF["保留原始回复；Final Answer error Observation"]
    P -->|解析失败| E["Parse error Observation"]
    P -->|成功| R{"工具名在注册表？"}
    R -->|否| E2["unknown tool Observation"]
    R -->|是| T["执行工具"]
    T -->|抛异常| E3["Tool error Observation"]
    T -->|正常返回| I{"启用注入且尚未注入？"}
    I -->|是| INJ["用注入错误替换返回值"]
    I -->|否| O["保留真实返回值"]
    E --> S["记录 step；回填 Observation"]
    EF --> S
    E2 --> S
    E3 --> S
    INJ --> S
    O --> S
    S --> K{"还剩循环预算？"}
    K -->|是| C
    K -->|否| STOP["空 final_answer，success=False"]
```

这里的“异常离开 run”特指模型调用异常；工具异常被捕获成 Observation。不能笼统说所有错误都能自动恢复。

## 4. 用两步依赖任务走一遍

以报告中的“查出生年份并计算到 2026 年的年龄”为例，以下为精简示意，不是复制模型隐藏推理：

```text
User: 查询出生年份并计算年龄。
Assistant:
Thought: 先获取年份。
Action: wiki
Action Input: {"query": "Geoffrey Hinton"}

程序执行 wiki。
Observation: 条目给出出生年份 1947。

Assistant:
Thought: 使用查询得到的年份计算。
Action: calculator
Action Input: {"expression": "2026 - 1947"}

程序执行 calculator。
Observation: 79

Assistant:
Thought: 已获得回答所需信息。
Final Answer: 出生于 1947 年；2026 年生日后为 79 岁，生日前为 78 岁。
```

关键依赖是 `wiki 的年份 → calculator 的参数`。只检查两个工具都出现，尚不能证明第二步真的使用第一步结果。

## 5. 两种消息协议

### 5.1 手写文本 ReAct

```python
messages = [
    {"role": "system", "content": "工具描述、格式和行为规则"},
    {"role": "user", "content": task},
    {"role": "assistant", "content": "Thought: ...\nAction: ...\nAction Input: {...}"},
    {"role": "user", "content": "Observation: 真实工具结果"},
]
```

所有 Action 标签都是普通文本；API 不会因为看到了字符串 `Action: calculator` 就自动执行函数。是自己的 parser 和 router 完成执行。

### 5.2 原生 tool calls

```json
[
  {"role": "user", "content": "计算 6 * 7"},
  {
    "role": "assistant",
    "content": null,
    "tool_calls": [{
      "id": "call_1",
      "type": "function",
      "function": {"name": "calculator", "arguments": "{\"expression\":\"6 * 7\"}"}
    }]
  },
  {"role": "tool", "tool_call_id": "call_1", "content": "42"}
]
```

工具定义由请求中的 `tools` 提供。应用仍需执行函数，并将结果关联到正确的 `tool_call_id`；常见 Chat Completions 接口中的 `arguments` 仍是 JSON 字符串，仍需解析和校验。[DeepSeek Tool Calls](https://api-docs.deepseek.com/guides/tool_calls/)

原生工具调用是接口协议，ReAct 是决策与反馈模式：二者可以结合。没有公开的 Thought 字段，并不能据此判定模型没有推理。

> [!important] Thought 与隐藏推理
> 复习和审计记录简短决策说明、动作、参数与证据即可，不要求模型暴露完整内部思维链。某些后端对机器间续传字段另有要求，应按该后端协议保留；机器协议要求不等于需要在人类日志中公开所有内容。

## 6. 解析与终止的真实边界

| 实现 | 当前行为 | 尚未保证的事 |
|---|---|---|
| `parse_action` | 正则找标签；去开头代码围栏；raw_decode 读首个 JSON 值；必须为 dict | 不完整验证整条响应只包含一个动作，可能忽略尾随内容 |
| `parse_thought` | 抽取 Thought 到 Action/Final Answer 之间的文字 | 不评分思考质量，也不验证是否依据证据 |
| `parse_final_answer` | 匹配到非空 Final Answer 即结束 | 不检查必要工具是否执行、信息是否充分 |
| system prompt | 要求至少收到一次 Observation 才回答 | 当前程序未把该规则实现成确定性停机门槛 |

若同一响应里既有 Action 又有伪造 Observation/Final Answer，当前流程先检查 Final Answer，可能提前结束。文字要求和执行器约束必须区分。

`success=True` 只表示解析到最终回答，不是题目判分。最终回答这一轮提前返回，因此不会再作为普通 step 加入 `steps`；它的 raw output 和最终 Thought 也没有完整保留。

## 7. max_steps 与三种重试

| 机制 | 发生位置 | 当前实现 |
|---|---|---|
| `max_steps` | run 外层循环 | 默认 8 次模型决策轮次 |
| 手写 `max_retries` | get_response 内部 | 默认 5 次尝试，主要处理空 content；API 异常和空 choices 直接抛错 |
| SDK 的传输重试 | SDK 内部 | 可能另有默认重试，不能只凭外层次数估算真实网络请求数 |
| 工具错误后的重新决策 | 下一轮 ReAct | 模型看到 Observation 后重试、改参数或换工具；属于行为恢复 |

重要边界：

- 7 次工具调用 + 第 8 轮 Final Answer 可以成功。
- 若第 8 轮才完成最后一次工具调用，结果已取得，但没有第 9 轮机会生成回答，当前实现仍会返回失败。
- `len(steps)` 通常不含最终回答轮，但可包含解析失败步骤，不能当作精确模型请求数。
- 原生协议中 `content=None` 且 `tool_calls` 非空是正常调用意图，不能套用文本客户端的“空 content 就重试”。

## 8. 通过本节应掌握什么

能手工展开一次 messages；区分提议动作和真正执行；解释 Observation 如何改变下一轮；识别“模型自称完成”与外部完成证据的区别。还要理解：ReAct 的价值可以用行为实验检验，不应靠 Thought 文本是否长而判断。

## 9. 自测

1. 模型输出 Action 文本后，谁真正执行 calculator？
	1. agent去执行
2. parse_thought 只存日志，是否意味着 Thought 对后续行为完全无影响？
	1. thought是模型内行为，可以用来帮助agent理解；也是后续token的输入
3. 原生 tool calls 与 ReAct 是否互斥？
	1. 并不互斥，只是tool的传递从prompt内换了接口
4. 为什么工具正常返回并不代表当前任务已完成？
	1. 工具的选择以及结果可能并非想要的
5. max_steps=8，第 8 轮才得到最后一个工具结果，当前实现会怎样？
	1. 终止，输出结果失败
6. 为什么 len(steps) 不能直接当作模型 API 调用次数？
	1. 没有记录final answer的次数
7. 模型 API 超时重试和 S4 的恢复动作有什么不同？
	1. API 重试一般只是重复传输同一请求；S4 要求模型接收到错误 Observation 后产生后续动作。
8. “调用工具前禁止 Final Answer”写进 prompt 后，程序是否已经强制保证？
	1. 没有保证，只是文字解析

### 自测标准答案

> [!success]- 标准答案：1. 应用执行器
> 模型生成工具名和参数，Python 解析后通过注册表调用真实函数。普通聊天 API 不理解自定义 Action 标签的执行语义。

> [!success]- 标准答案：2. 仍可能影响模型
> 原始回复包含 Thought，并会回填历史；自回归生成的后续 Action 也可能以它为条件。没有的是独立程序层面的思考评分与规划验证。

> [!success]- 标准答案：3. 属于不同层次
> tool calls 规定调用请求和结果如何编码，ReAct 描述如何反复决策、行动并利用反馈。原生协议可以承载相同反馈闭环。

> [!success]- 标准答案：4. 工具局部成功不等于全任务成功
> 结果可能为空、不相关、缺少另一子问题的信息，或尚未进入最终答案。完成条件应覆盖任务要求及证据。

> [!success]- 标准答案：5. 当前会失败
> 工具结果回填后预算已耗尽，无法再生成最终回答，返回空 final_answer。更完善的预算设计可分别限制工具调用与收尾生成。

> [!success]- 标准答案：6. 记录粒度不同
> 最终回答轮未进 steps；格式错误可进 steps；一次 call_model 内可能请求多次；SDK 也可能重试。

> [!success]- 标准答案：7. 是否看到错误并重新决策
> API 重试一般只是重复传输同一请求；S4 要求模型接收到错误 Observation 后产生后续动作。

> [!success]- 标准答案：8. 还没有
> 当前先解析 Final Answer 并直接返回。硬性要求必须由状态检查或独立验收来保证，不能只依赖文字约束。
