---
tags: [LLM, Agent, Tool-Calling, JSON-Schema, 安全]
aliases: [Agent 工具系统, Tool Schema 与路由]
updated: 2026-09-10
---

# Task 5.2：工具 Schema、路由与安全边界

> [!summary] 核心结论
> Schema 告诉模型“接口长什么样”，注册表决定“可以调用哪些函数”，执行器和工具决定“实际允许什么”。Schema 合法、工具执行无异常、返回值对任务有用，是三个不同层次。

返回总览：[[Task5-Tool-Agent学习索引]]  
代码定位：`src/tools/`；`src/agent.py::build_tool_registry/build_tool_schemas`。

## 1. parameters 为什么是 dict，工具如何支持多参数

```json
{
  "type": "function",
  "function": {
    "name": "file_search",
    "description": "Search file names and text under an allowed local directory.",
    "parameters": {
      "type": "object",
      "properties": {
        "pattern": {"type": "string"},
        "dir": {"type": "string"}
      },
      "required": ["pattern", "dir"],
      "additionalProperties": false
    }
  }
}
```

`parameters` 是描述调用参数的 JSON Schema，本身是对象；`properties` 可以包含多个字段，`required` 是必填字段名列表。模型实际提供：

```json
{"pattern": "TODO", "dir": "data/agent-fixtures"}
```

这份 schema 描述的是 object 参数，不是 `["TODO", "data/agent-fixtures"]` 位置参数列表。某一个属性本身仍然可以是 array，例如 `{"paths": ["a.md", "b.md"]}`，并不意味着工具“不支持 list”。

## 2. 从说明到执行有四道关

```mermaid
flowchart LR
    S["工具描述与 Schema"] --> M["模型产生名字和参数"]
    M --> P["解析与参数校验"]
    P --> R["注册表白名单"]
    R --> T["工具内部边界与真实执行"]
    T --> O["结果或错误 Observation"]
```

当前手写版只把 schema 转成 prompt 文本，并没有向模型请求传入 `tools`，也没有调用统一 JSON Schema validator：

- `parse_action` 仅要求参数是 dict。
- `additionalProperties: false` 是接口声明，不会自动限制任意 Python 字典。
- 各工具做了不同程度的内部检查，不能假设它们都完整执行 schema。
- `build_tool_registry` 与 `build_tool_schemas` 分别维护，后续更换工具时要避免两者不同步。

原生调用/严格 schema 模式可改善格式约束，但业务参数与权限仍需工具端校验。[DeepSeek 工具调用说明](https://api-docs.deepseek.com/guides/tool_calls/)

## 3. 四个工具的实际实现

| 工具 | 输入 | 当前返回 | 已有措施 | 重要局限 |
|---|---|---|---|---|
| calculator | expression | 数值字符串 | AST 递归，运算符/函数/常量白名单 | 不支持 len/str；长度配置尚未用于强制限制，幂运算仍可消耗资源 |
| python_sandbox | code | stdout | 子进程、临时 cwd、2 秒超时、限制 import 与部分 builtins | 教学级限制；输出先捕获再截断，不是完整资源隔离 |
| file_search | pattern、dir | JSON 字符串，含 count/results/snippet | resolve 后检查根目录；最大文件 1 MB；最多 20 条 | 截断列表不能用于精确全库计数；文件遍历不等于索引搜索 |
| wiki | query | 摘要字符串；都未找到可能为 None | 中文优先，未找到时尝试英文；8 秒超时；截到 2000 字符 | 查询词不决定语言；中文调用抛异常时不会自然继续英文回退 |

### 3.1 calculator：执行语义来自 AST 白名单

允许数字、基本算术、一元正负号、`sqrt/sin/cos/log/abs`、`pi/e`。不支持任意变量、属性访问或任意函数调用。

历史 S2 轨迹里模型曾输出 `len(str(456831))`，calculator 拒绝了 `len`。这说明路由和参数语义一起决定调用是否可用：模型选了“计算工具”，也可能传入超出能力范围的表达式。

配置类中存在 `max_expression_chars=500`，但当前 `run/calculate` 没有应用这个值；不能把“声明了限制”写成“已实现限制”。

### 3.2 python_sandbox：stdout 才是可见结果

脚本不是 notebook：

```python
n = 456831
len(str(n))         # 不会自动打印
print(len(str(n)))  # stdout 才能回到 Observation
```

空 stdout 可能意味着忘记 print，而非模型 API 返回空内容。两种空结果发生在不同层。

当前允许 import 的顶层模块是 `math/statistics`，并限制 `open/exec/eval`。这些约束有教学价值，但 Python 反射和资源耗尽等风险未被完整隔离。未来处理真正不可信代码时，再采用独立容器/进程权限与 CPU、内存、输出、网络配额。

### 3.3 file_search：匹配规则和返回范围要明确

- 文件名用 `fnmatch`，大小写不敏感，支持 `*.md`。
- 内容用原文 `text.find(pattern)`，是大小写敏感的字面子串匹配，不是同一套 glob 语义。
- 文件名与内容同时匹配时，只返回该文件一条结果，`matched_in` 同时包含 `filename/content`。
- 内容命中优先提供附近片段；只有文件名命中时返回开头片段。
- 顶层 `count` 是返回条数，不保证是所有命中总数；`truncated` 需要一起看。
- 允许根目录内的绝对路径，并非禁止所有绝对路径。关键在 resolve 后是否仍位于根内。
- 允许根目前是项目目录；路径不越界不等于目录里的所有文件都适合发给模型。后续还应把凭据文件和敏感子目录排除。

现有 Task10 的夹具很短，开头片段足以覆盖第一段；不能据此宣称已实现通用完整文件读取。

### 3.4 wiki：None、异常与未命中要区分

中文搜索没命中才尝试英文。中文网络请求直接抛异常时，错误由 Agent 捕获，当前 wiki 函数不会自动执行英文分支。

若中文和英文都未找到，工具可能返回 `None`，Agent 会把它转成字符串 `"None"`。这属于“函数正常返回但结果无用”，不是良好的成功证据。

## 4. 推荐的统一返回契约

以下是后续设计建议，当前 Task5 尚未全面实现：

```json
{
  "ok": false,
  "tool": "wiki",
  "data": null,
  "error": {
    "code": "TIMEOUT",
    "retryable": true,
    "message": "Request timed out"
  },
  "truncated": false,
  "duration_ms": 8000
}
```

`retryable` 只是恢复策略输入；是否真正重试，还要结合预算、任务状态与副作用判断。权限拒绝不应通过不断尝试绕过；参数错误应先修参数。

成功结果可以保留来源标识、文件路径/行号和检索时间，让后续答案能够引用证据。给模型的精简摘要和审计用原始记录可以分开存储。

## 5. Prompt、原生协议与权限的职责

| 内容 | 放在哪里 |
|---|---|
| 工具名、输入类型、必填字段 | schema；文本 ReAct 还需把信息写进 prompt |
| 什么时候应该调用、结果如何用于任务 | system prompt / 示例 |
| 路径是否可读、代码是否可运行 | 工具执行器，不能由模型自行放宽 |
| 参数是否符合类型与业务规则 | 调用前校验 + 工具内部校验 |
| 结果是否足以回答问题 | 模型后续决策 + 独立验收 |

工具结果是数据，不应因为来自工具就提升成 system 指令。网页或文件中出现“忽略之前规则”应当被当作外部内容处理，见 [[Task5-08-现代Agent优化与行为复习]]。

## 6. 本节要掌握的知识

能写出多参数 schema，区分 schema 对象和实际参数对象；能指出一个限制到底只是配置还是已被执行；能解释 empty/None/error 的差异；能通过输出格式帮助模型正确使用工具。

## 7. 自测

1. parameters 是对象，是否意味着工具只能接收一个参数？
	1. 对象内部不同的key作为不同参数
2. 写 additionalProperties=false 后，任意 Python 调用是否自动拒绝额外键？
	1. 没有实现自动拒绝
3. 文件名和内容都匹配时，当前 file_search 返回几条记录？
	1. 一条，但是两个flag都为True
4. count=20、truncated=true，能否回答目录里恰好 20 个目标文件？
5. 沙箱代码运行成功但 Observation 为空，先检查什么？
	1. 输出流是否正常
6. query 用英文是否保证 wiki 访问英文站点？
	1. 不能，部分英文在中文站点有信息，则优先访问
7. calculator 有 max_expression_chars 配置，为什么仍不能认定限制已生效？
	1. 实际没限制
8. 工具函数没抛异常，是否意味着有足够的有效证据？
	1. 结果需要校验才能判断

### 自测标准答案

> [!success]- 标准答案：1. 多个属性就是多个参数
> properties 可以声明多个字段，required 列出必填项；字段还可以嵌套对象或数组。

> [!success]- 标准答案：2. 需要执行校验
> schema 是声明。当前文本模式没有统一 validator，普通 Python dict 不会因 schema 文件存在而自动被检查。

> [!success]- 标准答案：3. 一条
> 同一结果的 matched_in 同时标明 filename 和 content，优先返回内容命中附近的片段。

> [!success]- 标准答案：4. 不能
> count 是已返回数量，命中可能更多；需要未截断的统计或专门的计数接口。

> [!success]- 标准答案：5. 是否打印
> Python 脚本不会自动回显最后一个表达式，需要 print。也要区分程序 stdout、工具返回值和模型响应 content。

> [!success]- 标准答案：6. 不保证
> 当前实现固定先访问中文站点。只有未找到摘要才尝试英文，中文抛异常不属于正常回退路径。

> [!success]- 标准答案：7. 配置没有接入执行路径
> 必须在实际入口校验长度；资源限制还应覆盖指数、结果规模和运行时间，不能只看配置名。

> [!success]- 标准答案：8. 不等于
> None、空串、无关摘要和截断片段都可能正常返回。还要检验结果的可用性、相关性和任务覆盖。
